---------------- How to config ---------------------

# You should put glut32.dill file to your system folder.
# first you can download it from provided link.
https://osdn.net/projects/sfnet_openman/downloads/openman/lib/glut32.lib/
# And you should move this file to �C:\Windows\System32�.
# After moving this file, you can play the snake game.
# Some times there can be an error glut32.dill not found.
# If you got that kind of error you should copy that glut32.dill file and past it to �C:\Windows\SysWOW64� also.

****** play and enjoy**********

----------------- How to play ------------------------

To move the snake, use 'up arrow' for going up, 'down arrow' for down, 'left arrow' for
going left and 'right arrow' for right. press End button to exit game at any time. The aim of the game is to collect the dots (food) and avoid the obstacles (crosses, borders and the snake itself), As you collect food, the snake gets longer, so increasing your like hood of crashing into yourself. When you have collected enough food and got 25 points you have select onto the next level. Users can collect scores depend on length of snake. The speed increases every three level. There is no concept of lives. Hence you hit the outline border or itself, the game over.
